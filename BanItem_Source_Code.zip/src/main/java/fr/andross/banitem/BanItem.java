
package fr.andross.banitem;

import org.bukkit.plugin.java.JavaPlugin;
import io.papermc.paper.threadedregions.scheduler.GlobalRegionScheduler;
import java.util.concurrent.TimeUnit;

public class BanItem extends JavaPlugin {

    @Override
    public void onEnable() {
        // Example of Folia-compatible scheduling
        GlobalRegionScheduler scheduler = this.getServer().getGlobalRegionScheduler();

        scheduler.runAtFixedRate(
            this,
            task -> {
                getLogger().info("Scheduled task running on Folia-compatible scheduler!");
            },
            0, // Initial delay
            20, // Period (ticks, 1 second in Minecraft time)
            TimeUnit.MILLISECONDS
        );

        getLogger().info("BanItem has been enabled with Folia support!");
    }

    @Override
    public void onDisable() {
        getLogger().info("BanItem has been disabled.");
    }
}
    